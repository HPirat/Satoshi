# Beta version: Satoshi tools

# Ip: Dos: Car: Info: Number:

# Termux
# 1. pkg update -y && upgrade -y
# 2. pkg install git -y python -y
# 3. pip install requests bs4 
# 5. cd satoshi
# 6. python3 satoshi.py



# sudo apt-get install git 
# sudo apt-get install python3
# pip3 install requests 
# cd Satoshi
# python3 satoshi.py